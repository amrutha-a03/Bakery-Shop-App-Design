import { createBrowserRouter } from 'react-router';
import { Welcome } from './screens/Welcome';
import { Home } from './screens/Home';
import { Products } from './screens/Products';
import { ProductDetail } from './screens/ProductDetail';
import { Cart } from './screens/Cart';
import { Checkout } from './screens/Checkout';
import { Payment } from './screens/Payment';
import { Confirmation } from './screens/Confirmation';
import { Profile } from './screens/Profile';
import { Wishlist } from './screens/Wishlist';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Welcome,
  },
  {
    path: '/home',
    Component: Home,
  },
  {
    path: '/products',
    Component: Products,
  },
  {
    path: '/product/:id',
    Component: ProductDetail,
  },
  {
    path: '/cart',
    Component: Cart,
  },
  {
    path: '/wishlist',
    Component: Wishlist,
  },
  {
    path: '/checkout',
    Component: Checkout,
  },
  {
    path: '/payment',
    Component: Payment,
  },
  {
    path: '/confirmation',
    Component: Confirmation,
  },
  {
    path: '/profile',
    Component: Profile,
  },
]);
