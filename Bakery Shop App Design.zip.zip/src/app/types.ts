export interface Product {
  id: string;
  name: string;
  category: 'cakes' | 'pastries' | 'breads' | 'desserts';
  price: number;
  image: string;
  description: string;
  rating: number;
  popular?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
  customization?: {
    size?: string;
    flavor?: string;
    message?: string;
  };
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'delivered';
  date: string;
  deliveryAddress: string;
}
