import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { ArrowLeft } from 'lucide-react';

export const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const { cart, user } = useApp();
  const [deliveryType, setDeliveryType] = useState('delivery');
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [address, setAddress] = useState(user?.address || '');
  const [notes, setNotes] = useState('');

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = deliveryType === 'delivery' ? 5.99 : 0;
  const total = subtotal + deliveryFee;

  const handleContinue = () => {
    if (!name || !phone || (deliveryType === 'delivery' && !address)) {
      alert('Please fill in all required fields');
      return;
    }
    navigate('/payment', {
      state: { name, phone, address, notes, deliveryType, total },
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card border-b border-border p-4">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/cart')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2>Checkout</h2>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 mt-6">
        {/* Delivery Method */}
        <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Delivery Method</h3>
          <RadioGroup value={deliveryType} onValueChange={setDeliveryType}>
            <div className="flex items-center justify-between p-4 border border-border rounded-lg mb-3">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="delivery" id="delivery" />
                <Label htmlFor="delivery" className="cursor-pointer">
                  <div>
                    <p>Home Delivery</p>
                    <p className="text-sm text-muted-foreground">
                      Delivered to your doorstep
                    </p>
                  </div>
                </Label>
              </div>
              <span className="text-primary">$5.99</span>
            </div>
            <div className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="pickup" id="pickup" />
                <Label htmlFor="pickup" className="cursor-pointer">
                  <div>
                    <p>Store Pickup</p>
                    <p className="text-sm text-muted-foreground">
                      Pick up at our bakery
                    </p>
                  </div>
                </Label>
              </div>
              <span className="text-green-600">Free</span>
            </div>
          </RadioGroup>
        </div>

        {/* Contact Information */}
        <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Contact Information</h3>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Doe"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 234 567 8900"
                className="mt-1"
              />
            </div>
          </div>
        </div>

        {/* Delivery Address */}
        {deliveryType === 'delivery' && (
          <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
            <h3 className="mb-4">Delivery Address</h3>
            <div>
              <Label htmlFor="address">Street Address *</Label>
              <Textarea
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="123 Main St, Apt 4B"
                className="mt-1 resize-none"
              />
            </div>
          </div>
        )}

        {/* Additional Notes */}
        <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Additional Notes</h3>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Any special instructions for delivery..."
            className="resize-none"
          />
        </div>

        {/* Order Summary */}
        <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Order Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal ({cart.length} items)</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Delivery Fee</span>
              <span>
                {deliveryFee === 0 ? 'FREE' : `$${deliveryFee.toFixed(2)}`}
              </span>
            </div>
            <div className="border-t border-border pt-3 flex justify-between">
              <span>Total</span>
              <span className="text-xl text-primary">${total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Continue Button */}
        <Button
          size="lg"
          onClick={handleContinue}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-4"
        >
          Continue to Payment
        </Button>
      </div>
    </div>
  );
};
