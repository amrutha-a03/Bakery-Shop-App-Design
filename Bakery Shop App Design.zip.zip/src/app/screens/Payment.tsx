import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { ArrowLeft, CreditCard, Wallet } from 'lucide-react';

export const Payment: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cart, clearCart, addOrder } = useApp();
  const { name, phone, address, notes, deliveryType, total } = location.state || {};

  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePayment = () => {
    if (paymentMethod === 'card') {
      if (!cardNumber || !cardName || !expiryDate || !cvv) {
        alert('Please fill in all card details');
        return;
      }
    }

    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      const order = {
        id: `ORD-${Date.now()}`,
        items: cart,
        total,
        status: 'pending' as const,
        date: new Date().toISOString(),
        deliveryAddress: deliveryType === 'delivery' ? address : 'Store Pickup',
      };

      addOrder(order);
      clearCart();
      navigate('/confirmation', { state: { order } });
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card border-b border-border p-4">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/checkout')}
            disabled={isProcessing}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2>Payment</h2>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 mt-6">
        {/* Payment Method Selection */}
        <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Payment Method</h3>
          <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
            <div className="flex items-center justify-between p-4 border border-border rounded-lg mb-3">
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="card" id="card" />
                <CreditCard className="h-5 w-5 text-primary" />
                <Label htmlFor="card" className="cursor-pointer">
                  Credit / Debit Card
                </Label>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border border-border rounded-lg mb-3">
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="wallet" id="wallet" />
                <Wallet className="h-5 w-5 text-primary" />
                <Label htmlFor="wallet" className="cursor-pointer">
                  Digital Wallet
                </Label>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="cod" id="cod" />
                <span className="text-2xl">💵</span>
                <Label htmlFor="cod" className="cursor-pointer">
                  Cash on Delivery
                </Label>
              </div>
            </div>
          </RadioGroup>
        </div>

        {/* Card Details */}
        {paymentMethod === 'card' && (
          <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
            <h3 className="mb-4">Card Details</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input
                  id="cardNumber"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="cardName">Cardholder Name</Label>
                <Input
                  id="cardName"
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  placeholder="John Doe"
                  className="mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input
                    id="expiry"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    placeholder="MM/YY"
                    maxLength={5}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    type="password"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value)}
                    placeholder="123"
                    maxLength={3}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Digital Wallet Info */}
        {paymentMethod === 'wallet' && (
          <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
            <div className="text-center py-8">
              <Wallet className="h-16 w-16 text-primary mx-auto mb-4" />
              <h3 className="mb-2">Pay with Digital Wallet</h3>
              <p className="text-muted-foreground">
                You'll be redirected to complete the payment
              </p>
            </div>
          </div>
        )}

        {/* Cash on Delivery Info */}
        {paymentMethod === 'cod' && (
          <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
            <div className="text-center py-8">
              <span className="text-6xl mb-4 block">💵</span>
              <h3 className="mb-2">Cash on Delivery</h3>
              <p className="text-muted-foreground">
                Pay when your order arrives
              </p>
            </div>
          </div>
        )}

        {/* Order Total */}
        <div className="bg-gradient-to-r from-primary to-accent p-6 rounded-xl shadow-md mb-6">
          <div className="flex justify-between items-center text-white">
            <span className="text-lg">Total Amount</span>
            <span className="text-3xl">${total?.toFixed(2)}</span>
          </div>
        </div>

        {/* Pay Button */}
        <Button
          size="lg"
          onClick={handlePayment}
          disabled={isProcessing}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-4"
        >
          {isProcessing ? 'Processing...' : `Pay $${total?.toFixed(2)}`}
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          By completing this purchase, you agree to our terms and conditions
        </p>
      </div>
    </div>
  );
};
