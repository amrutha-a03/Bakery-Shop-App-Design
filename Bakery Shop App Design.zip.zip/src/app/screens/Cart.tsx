import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { ArrowLeft, Trash2, Tag } from 'lucide-react';
import { MobileNav } from '../components/MobileNav';
import { toast } from 'sonner';

export const Cart: React.FC = () => {
  const navigate = useNavigate();
  const { cart, updateCartQuantity, removeFromCart } = useApp();
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = subtotal > 30 ? 0 : 5.99;
  const total = subtotal + deliveryFee - discount;

  const applyPromoCode = () => {
    if (promoCode.toUpperCase() === 'SWEET20') {
      setDiscount(subtotal * 0.2);
      toast.success('Promo code applied! 20% off');
    } else {
      toast.error('Invalid promo code');
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <div className="sticky top-0 z-40 bg-card border-b border-border p-4">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/home')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2>Shopping Cart</h2>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center py-20 px-6">
          <div className="text-6xl mb-4">🛒</div>
          <h3 className="mb-2">Your cart is empty</h3>
          <p className="text-muted-foreground text-center mb-6">
            Add some delicious items to your cart
          </p>
          <Button
            onClick={() => navigate('/products')}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            Browse Products
          </Button>
        </div>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card border-b border-border p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/home')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2>Shopping Cart</h2>
          </div>
          <span className="text-sm text-muted-foreground">{cart.length} items</span>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 mt-4">
        {/* Cart Items */}
        <div className="space-y-4 mb-6">
          {cart.map((item) => (
            <div
              key={item.id}
              className="flex gap-4 bg-card p-4 rounded-xl shadow-sm border border-border"
            >
              <img
                src={item.image}
                alt={item.name}
                className="w-24 h-24 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h4 className="mb-1">{item.name}</h4>
                {item.customization && (
                  <div className="text-xs text-muted-foreground mb-2">
                    {item.customization.size && (
                      <span>Size: {item.customization.size} • </span>
                    )}
                    {item.customization.flavor && (
                      <span>Flavor: {item.customization.flavor}</span>
                    )}
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-primary">${item.price.toFixed(2)}</span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                      className="h-8 w-8 p-0 rounded-full"
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{item.quantity}</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                      className="h-8 w-8 p-0 rounded-full"
                    >
                      +
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        removeFromCart(item.id);
                        toast.success('Item removed from cart');
                      }}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Promo Code */}
        <div className="bg-card p-4 rounded-xl shadow-sm border border-border mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Tag className="h-5 w-5 text-primary" />
            <h4>Promo Code</h4>
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Enter code (try SWEET20)"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
            />
            <Button
              onClick={applyPromoCode}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              Apply
            </Button>
          </div>
        </div>

        {/* Order Summary */}
        <div className="bg-card p-6 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Order Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Delivery Fee</span>
              <span>{deliveryFee === 0 ? 'FREE' : `$${deliveryFee.toFixed(2)}`}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Discount</span>
                <span>-${discount.toFixed(2)}</span>
              </div>
            )}
            <div className="border-t border-border pt-3 flex justify-between">
              <span>Total</span>
              <span className="text-xl text-primary">${total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Checkout Button */}
      <div className="fixed bottom-16 left-0 right-0 p-4 bg-card border-t border-border md:max-w-md md:mx-auto">
        <Button
          size="lg"
          onClick={() => navigate('/checkout')}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          Proceed to Checkout - ${total.toFixed(2)}
        </Button>
      </div>

      <MobileNav />
    </div>
  );
};
