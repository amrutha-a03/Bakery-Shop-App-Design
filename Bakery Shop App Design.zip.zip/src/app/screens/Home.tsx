import React from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { ProductCard } from '../components/ProductCard';
import { products } from '../data/products';
import { Search, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router';
import { MobileNav } from '../components/MobileNav';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = React.useState('');

  const categories = [
    { name: 'Cakes', icon: '🎂', value: 'cakes' },
    { name: 'Pastries', icon: '🥐', value: 'pastries' },
    { name: 'Breads', icon: '🍞', value: 'breads' },
    { name: 'Desserts', icon: '🍰', value: 'desserts' },
  ];

  const popularProducts = products.filter((p) => p.popular);
  const featuredProducts = products.slice(0, 4);

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-accent p-6 rounded-b-3xl shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-white">Good Morning! 👋</h1>
              <p className="text-white/80 text-sm mt-1">What would you like today?</p>
            </div>
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
              <span className="text-xl">🧑</span>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search for cakes, pastries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white border-none shadow-md"
            />
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6">
        {/* Categories */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h2>Categories</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/products')}
              className="text-primary"
            >
              See All
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => navigate(`/products?category=${category.value}`)}
                className="flex flex-col items-center gap-2 p-4 bg-card rounded-2xl shadow-sm hover:shadow-md transition-all hover:-translate-y-1 border border-border"
              >
                <span className="text-3xl">{category.icon}</span>
                <span className="text-xs text-center">{category.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Special Offer */}
        <div className="mt-6 bg-gradient-to-r from-accent to-secondary p-6 rounded-2xl shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="mb-1">Weekend Special! 🎉</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Get 20% off on all cakes
              </p>
              <Button
                size="sm"
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                onClick={() => navigate('/products?category=cakes')}
              >
                Shop Now
              </Button>
            </div>
            <div className="text-6xl">🎂</div>
          </div>
        </div>

        {/* Popular Items */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h2>Popular Items</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/products')}
              className="text-primary"
            >
              View All
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {popularProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>

        {/* Featured Products */}
        <div className="mt-6 mb-4">
          <h2 className="mb-4">Fresh From Oven</h2>
          <div className="grid grid-cols-2 gap-4">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>

      <MobileNav />
    </div>
  );
};
