import React from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { User, MapPin, Phone, Mail, ShoppingBag, ChevronRight, LogOut } from 'lucide-react';
import { MobileNav } from '../components/MobileNav';

export const Profile: React.FC = () => {
  const navigate = useNavigate();
  const { user, orders, setUser } = useApp();

  const handleLogout = () => {
    setUser(null);
    navigate('/');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-blue-600 bg-blue-100';
      case 'preparing':
        return 'text-yellow-600 bg-yellow-100';
      case 'delivered':
        return 'text-green-600 bg-green-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header with Profile Info */}
      <div className="bg-gradient-to-br from-primary to-accent p-6 pb-12 rounded-b-3xl shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center">
              <User className="h-10 w-10 text-primary" />
            </div>
            <div className="text-white">
              <h2>{user?.name || 'Guest User'}</h2>
              <p className="text-white/80 text-sm">{user?.email}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 -mt-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Card className="p-4 text-center bg-card">
            <p className="text-2xl mb-1">{orders.length}</p>
            <p className="text-xs text-muted-foreground">Orders</p>
          </Card>
          <Card className="p-4 text-center bg-card">
            <p className="text-2xl mb-1">0</p>
            <p className="text-xs text-muted-foreground">Points</p>
          </Card>
          <Card className="p-4 text-center bg-card">
            <p className="text-2xl mb-1">0</p>
            <p className="text-xs text-muted-foreground">Rewards</p>
          </Card>
        </div>

        {/* Account Settings */}
        <div className="bg-card p-4 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Account Settings</h3>
          <div className="space-y-1">
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <User className="h-5 w-5 text-primary" />
                <span>Personal Information</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-primary" />
                <span>Saved Addresses</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary" />
                <span>Contact Preferences</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Order History */}
        <div className="bg-card p-4 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Recent Orders</h3>
          {orders.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingBag className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No orders yet</p>
              <Button
                size="sm"
                onClick={() => navigate('/products')}
                className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Start Shopping
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.slice(0, 5).map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-4 border border-border rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => navigate('/confirmation', { state: { order } })}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm">{order.id}</p>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${getStatusColor(
                          order.status
                        )}`}
                      >
                        {order.status}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(order.date).toLocaleDateString()} • {order.items.length}{' '}
                      items
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-primary">${order.total.toFixed(2)}</p>
                    <ChevronRight className="h-5 w-5 text-muted-foreground ml-auto" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Support & About */}
        <div className="bg-card p-4 rounded-xl shadow-sm border border-border mb-6">
          <h3 className="mb-4">Support & About</h3>
          <div className="space-y-1">
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <span>Help Center</span>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <span>Terms & Conditions</span>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <span>Privacy Policy</span>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-secondary rounded-lg transition-colors">
              <span>About Us</span>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Logout Button */}
        <Button
          variant="outline"
          onClick={handleLogout}
          className="w-full mb-4 text-destructive hover:text-destructive hover:bg-destructive/10"
        >
          <LogOut className="h-5 w-5 mr-2" />
          Logout
        </Button>

        <p className="text-xs text-center text-muted-foreground mb-4">
          Version 1.0.0
        </p>
      </div>

      <MobileNav />
    </div>
  );
};
