import React from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { ProductCard } from '../components/ProductCard';
import { ArrowLeft } from 'lucide-react';
import { MobileNav } from '../components/MobileNav';

export const Wishlist: React.FC = () => {
  const navigate = useNavigate();
  const { wishlist } = useApp();

  if (wishlist.length === 0) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <div className="sticky top-0 z-40 bg-card border-b border-border p-4">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/home')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2>My Wishlist</h2>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center py-20 px-6">
          <div className="text-6xl mb-4">💝</div>
          <h3 className="mb-2">Your wishlist is empty</h3>
          <p className="text-muted-foreground text-center mb-6">
            Save your favorite items to your wishlist
          </p>
          <Button
            onClick={() => navigate('/products')}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            Browse Products
          </Button>
        </div>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card border-b border-border p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/home')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2>My Wishlist</h2>
          </div>
          <span className="text-sm text-muted-foreground">
            {wishlist.length} items
          </span>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 mt-6">
        <div className="grid grid-cols-2 gap-4">
          {wishlist.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>

      <MobileNav />
    </div>
  );
};
