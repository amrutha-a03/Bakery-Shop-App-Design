import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { products } from '../data/products';
import { Button } from '../components/ui/button';
import { ArrowLeft, Heart, Star, ShoppingCart } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Textarea } from '../components/ui/textarea';
import { toast } from 'sonner';

export const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, addToWishlist, wishlist, removeFromWishlist } = useApp();

  const product = products.find((p) => p.id === id);
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('regular');
  const [selectedFlavor, setSelectedFlavor] = useState('original');
  const [customMessage, setCustomMessage] = useState('');
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Product not found</p>
      </div>
    );
  }

  const isInWishlist = wishlist.some((item) => item.id === product.id);

  const handleAddToCart = () => {
    addToCart(product, {
      size: selectedSize,
      flavor: selectedFlavor,
      message: customMessage,
    });
    toast.success('Added to cart!');
    setIsCustomizeOpen(false);
  };

  const handleWishlist = () => {
    if (isInWishlist) {
      removeFromWishlist(product.id);
      toast.success('Removed from wishlist');
    } else {
      addToWishlist(product);
      toast.success('Added to wishlist!');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Image Section */}
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-80 object-cover"
        />
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 left-4 bg-white/90 hover:bg-white rounded-full"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 bg-white/90 hover:bg-white rounded-full"
          onClick={handleWishlist}
        >
          <Heart
            className={`h-5 w-5 ${
              isInWishlist ? 'fill-red-500 text-red-500' : 'text-gray-600'
            }`}
          />
        </Button>
      </div>

      {/* Content */}
      <div className="bg-background rounded-t-3xl -mt-6 relative z-10 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="mb-2">{product.name}</h1>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  <span>{product.rating}</span>
                </div>
                <span className="text-muted-foreground">• {product.category}</span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl text-primary">${product.price.toFixed(2)}</p>
            </div>
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="mb-2">Description</h3>
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          {/* Quantity Selector */}
          <div className="mb-6">
            <h3 className="mb-3">Quantity</h3>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="rounded-full"
              >
                -
              </Button>
              <span className="w-12 text-center">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(quantity + 1)}
                className="rounded-full"
              >
                +
              </Button>
            </div>
          </div>

          {/* Customization Options */}
          <div className="mb-6">
            <Dialog open={isCustomizeOpen} onOpenChange={setIsCustomizeOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  Customize Your Order
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Customize {product.name}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  {/* Size */}
                  <div>
                    <Label className="mb-2 block">Size</Label>
                    <RadioGroup value={selectedSize} onValueChange={setSelectedSize}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="small" id="small" />
                        <Label htmlFor="small" className="cursor-pointer">
                          Small
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="regular" id="regular" />
                        <Label htmlFor="regular" className="cursor-pointer">
                          Regular
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="large" id="large" />
                        <Label htmlFor="large" className="cursor-pointer">
                          Large
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Flavor */}
                  <div>
                    <Label className="mb-2 block">Flavor</Label>
                    <RadioGroup
                      value={selectedFlavor}
                      onValueChange={setSelectedFlavor}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="original" id="original" />
                        <Label htmlFor="original" className="cursor-pointer">
                          Original
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="vanilla" id="vanilla" />
                        <Label htmlFor="vanilla" className="cursor-pointer">
                          Vanilla
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="chocolate" id="chocolate" />
                        <Label htmlFor="chocolate" className="cursor-pointer">
                          Chocolate
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="strawberry" id="strawberry" />
                        <Label htmlFor="strawberry" className="cursor-pointer">
                          Strawberry
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Custom Message */}
                  <div>
                    <Label htmlFor="message" className="mb-2 block">
                      Custom Message (Optional)
                    </Label>
                    <Textarea
                      id="message"
                      placeholder="Happy Birthday, John!"
                      value={customMessage}
                      onChange={(e) => setCustomMessage(e.target.value)}
                      className="resize-none"
                    />
                  </div>

                  <Button
                    onClick={handleAddToCart}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Add to Cart
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Add to Cart Button */}
          <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border md:max-w-md md:mx-auto">
            <div className="flex gap-3">
              <Button
                variant="outline"
                size="lg"
                onClick={handleWishlist}
                className="flex-shrink-0"
              >
                <Heart
                  className={`h-5 w-5 ${
                    isInWishlist ? 'fill-red-500 text-red-500' : ''
                  }`}
                />
              </Button>
              <Button
                size="lg"
                onClick={() => {
                  for (let i = 0; i < quantity; i++) {
                    addToCart(product);
                  }
                  toast.success('Added to cart!');
                }}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                Add to Cart - ${(product.price * quantity).toFixed(2)}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
