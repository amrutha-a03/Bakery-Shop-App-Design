import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { Button } from '../components/ui/button';
import { CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

export const Confirmation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { order } = location.state || {};

  useEffect(() => {
    // Trigger confetti animation
    const duration = 3000;
    const animationEnd = Date.now() + duration;

    const randomInRange = (min: number, max: number) => {
      return Math.random() * (max - min) + min;
    };

    const interval = setInterval(() => {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      confetti({
        particleCount: 3,
        angle: randomInRange(55, 125),
        spread: randomInRange(50, 70),
        origin: { x: randomInRange(0.1, 0.9), y: 0.6 },
        colors: ['#C89B7B', '#E8C4A8', '#F5E6D3'],
      });
    }, 50);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="max-w-md w-full text-center">
        {/* Success Animation */}
        <div className="mb-6">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 rounded-full mb-4 animate-bounce">
            <CheckCircle2 className="h-12 w-12 text-green-600" />
          </div>
          <h1 className="mb-2">Order Confirmed! 🎉</h1>
          <p className="text-muted-foreground">
            Thank you for your order. We're preparing your delicious treats!
          </p>
        </div>

        {/* Order Details */}
        <div className="bg-card p-6 rounded-xl shadow-lg border border-border mb-6">
          <div className="mb-4 pb-4 border-b border-border">
            <p className="text-sm text-muted-foreground mb-1">Order Number</p>
            <p className="text-lg">{order?.id}</p>
          </div>
          <div className="mb-4 pb-4 border-b border-border">
            <p className="text-sm text-muted-foreground mb-1">Total Amount</p>
            <p className="text-2xl text-primary">${order?.total.toFixed(2)}</p>
          </div>
          <div className="mb-4 pb-4 border-b border-border">
            <p className="text-sm text-muted-foreground mb-1">Delivery Address</p>
            <p className="text-sm">{order?.deliveryAddress}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Estimated Delivery</p>
            <p className="text-sm">30-45 minutes</p>
          </div>
        </div>

        {/* Order Items */}
        <div className="bg-card p-6 rounded-xl shadow-lg border border-border mb-6">
          <h3 className="mb-4 text-left">Order Items</h3>
          <div className="space-y-3">
            {order?.items.map((item: any) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {item.quantity}x {item.name}
                </span>
                <span>${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            size="lg"
            onClick={() => navigate('/profile')}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            Track Order
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => navigate('/home')}
            className="w-full"
          >
            Continue Shopping
          </Button>
        </div>

        {/* Thank You Message */}
        <div className="mt-8 p-4 bg-secondary rounded-xl">
          <p className="text-sm text-muted-foreground">
            We've sent a confirmation email with your order details. 
            You can track your order status in your profile.
          </p>
        </div>
      </div>
    </div>
  );
};
