
  # Bakery Shop App Design

  This is a code bundle for Bakery Shop App Design. The original project is available at https://www.figma.com/design/rddAjVubwe7HlZZ0L34ZqU/Bakery-Shop-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  